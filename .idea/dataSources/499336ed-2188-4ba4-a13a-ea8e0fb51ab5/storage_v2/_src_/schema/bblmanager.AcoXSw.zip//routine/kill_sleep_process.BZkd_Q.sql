create procedure KILL_SLEEP_PROCESS()
  BEGIN
  DECLARE cursor_ID INT;
  DECLARE done INT DEFAULT FALSE;
  DECLARE cursor_i CURSOR FOR SELECT id from information_schema.processlist where `Command` = 'Sleep';
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  OPEN cursor_i;
  read_loop: LOOP
    FETCH cursor_i INTO cursor_ID;
    IF done THEN
      LEAVE read_loop;
    END IF;
    KILL cursor_ID;
  END LOOP;
  CLOSE cursor_i;
END;

